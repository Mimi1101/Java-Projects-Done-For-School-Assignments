/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singlecorescheduler;

/**
 * A application to simulate a non-preemptive scheduler for a single-core CPU
 * using a heap-based implementation of a priority queue
 *
 * @author William Duncan, Bibhushita Baral
 * @see PQueue.java, PCB.java  <pre>
 * DATE: 9/21/2022
 * File:SingleCoreScheduler.java
 * Course: csc 3102
 * Programming Project # 1
 * Instructor: Dr. Duncan
 * Usage: SingleCoreScheduler <number of cylces> <-R or -r> <probability of a  process being created per cycle>  or,
 *        SingleCoreScheduler <number of cylces> <-F or -f> <file name of file containing processes>,
 *        The simulator runs in either random (-R or -r) or file (-F or -f) mode
 * </pre>
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

public class SingleCoreScheduler {

    /**
     * Single-core processor with non-preemptive scheduling simulator
     *
     * @param args an array of strings containing command line arguments args[0]
     * - number of cycles to run the simulation args[1] - the mode: -r or -R for
     * random mode and -f or -F for file mode 
     * args[2] - if the mode is random, this entry contains the probability that a process is created per cycle
     * and if the simulator is running in file mode, this entry contains the name of the file containing the the simulated jobs. In file mode, each
     * line of the input file is in this format:
     * <process ID> <priority value> <cycle of process creation>
     * <time> required to execute>
     */
    public static void main(String[] args) throws PQueueException, IOException {
        if (args.length != 3) {
            System.out.println("Usage: SingleCoreScheduler <number of cylces> <-R or -r> <probability of a  process being created per cycle>  or ");
            System.out.println("       SingleCoreScheduler <number of cylces> <-F or -f> <file name of file containing processes>");
            System.out.println("The simulator runs in either random (-R or -r) or file (-F or -f) mode.");
            System.exit(1);
        }
        boolean thisIsFile = false;
        Scanner FileYourJob = null;
        int NumberOfProcesses = 0;
        int NumberOfCycles = Integer.parseInt(args[0]);
        String fileOrRandom = args[1];
        if (fileOrRandom.equalsIgnoreCase("-f")) {
            thisIsFile = true;
        } else if (fileOrRandom.equalsIgnoreCase("-r")) {
            thisIsFile = false;
        } else {
            System.out.println("Please enter a valid mode: " + fileOrRandom);
            System.exit(1);
        }
        Random randomNumberGenerator = null;
        double randomNumberProbability = 0;
        if (thisIsFile) {
            try {
                FileYourJob = new Scanner(new FileReader(args[2]));
            } catch (FileNotFoundException e) {
                System.out.println("Invalid path for file: " + args[2]); 
                System.exit(1);
            }

        } else {
            randomNumberGenerator = new Random(System.currentTimeMillis());
            try {
                randomNumberProbability = Double.parseDouble(args[2]);
            } catch (NumberFormatException ee) {
                System.out.println("Invalid format for random: " + args[2]);
            }

        }
        PQueue<PCB> priorityQueue = new PQueue<>((PCB pcb1, PCB pcb2) -> { // this is the priority queue 
            int num = pcb2.compareTo(pcb1);
            if (num == 0) {
                return pcb1.getArrival() - pcb2.getArrival();
            }
            return num;
        });
        int WaitTime = 0;
        int TurnAround = 0;
        PCB activeProcess = null;
        PCB nextProcess = null;
        if (thisIsFile && FileYourJob.hasNextLine()) {
            int PID = FileYourJob.nextInt();
            int PriorityTime = FileYourJob.nextInt();
            int StartTime = FileYourJob.nextInt();
            int BurstTime = FileYourJob.nextInt();
            nextProcess = new PCB(PID, PriorityTime, 0, StartTime, BurstTime);
        }
        // all the executing and stop time calculation
        for (int i = 0; i < NumberOfCycles; i++) {
            System.out.println("*** Cycle#: " + i);
            if (priorityQueue.isEmpty() && activeProcess == null) {
                System.out.println("The CPU is idle.");
            } else {
                if (activeProcess == null) {
                    activeProcess = priorityQueue.remove();
                    activeProcess.setWait(i - activeProcess.getArrival());
                    WaitTime += activeProcess.getWait();
                    activeProcess.execute();
                    activeProcess.setStart(i);
                }
                if (activeProcess.getStart() + activeProcess.getBurst() == i) {
                    System.out.println("Process #" + activeProcess.getPid() + "has just terminated.");
                    TurnAround += activeProcess.getBurst();
                    activeProcess = null;
                } else {
                    System.out.println("Process #" + activeProcess.getPid() + "is executing.");
                }
            }
            if (thisIsFile && nextProcess != null && nextProcess.getArrival() == i) {
                NumberOfProcesses++;
                priorityQueue.insert(nextProcess);
                System.out.println(" Adding job with pid# " + nextProcess.getPid() + " and Priority " + nextProcess.getPriority() + " and Burst " + nextProcess.getBurst() + ".");
                nextProcess = null;
                if (FileYourJob.hasNextLine()) {
                    int PID = FileYourJob.nextInt();
                    int Priority = FileYourJob.nextInt();
                    int Start = FileYourJob.nextInt();
                    int Burst = FileYourJob.nextInt();
                    nextProcess = new PCB(PID, Priority, 0, Start, Burst);

                }

            } else if (!thisIsFile && randomNumberGenerator.nextDouble() <= randomNumberProbability) {
                PCB process = new PCB(NumberOfProcesses++, randomNumberGenerator.nextInt(21 + 19) - 19, 0, i, randomNumberGenerator.nextInt(101 - 1) + 1);
                System.out.println("Adding job with pid# " + process.getPid() + " and Priority " + process.getPriority() + " and Burst " + process.getBurst() + ".");
                priorityQueue.insert(process);

            } else {
                System.out.println("No new job this cycle.");
            }
        }

        if (FileYourJob != null) {
            FileYourJob.close();
        }

        System.out.println("The average number of process created per cycle is " + ((double) NumberOfProcesses / NumberOfCycles) + "."); 
        System.out.println("The throughput is " + ((double) TurnAround / NumberOfProcesses) + " per cycle.");
        System.out.println("The average wait time per process is " + ((double) WaitTime / NumberOfProcesses) + ".");

    }

}
